## BioModel 10 example
In this folder you find BioModel #10 already downloaded. 

* import the SBML file into COPASI 
* set up the parameter estimation data to decide which file to use, have a look at the species in your model if you have species named `MAPKKK-P` and `MAPK-P` use file `MAPKdata.txt`. Newer versions of the model have renamed those species, in that case use `MAPKdata_renamed.txt`
* estimate the reaction parameters 