## Basic Example

This model contains only a reaction with Michaelis Menten kinetics, as well as influx and outflux. 

* set up the parameter estimation problem
* add experimental data for f6p and g6p
* add the reaction parameters to be estimated
* experiment with several optimization algorithms
* How good is the fit?